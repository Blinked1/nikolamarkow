package com.example.ivan_projects

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
